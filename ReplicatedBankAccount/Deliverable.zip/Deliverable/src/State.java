public enum State {
    CONNECTING,
    WAITING,
    RUNNING,
    TERMINATING,
    SEND_UPDATE
}
